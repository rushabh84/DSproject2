/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rush
 */
import info.blockchain.api.blockexplorer.*;
import java.util.Scanner;

public class BitcoinProject {

    static String blockHash;
    static long blockHeight;
    static Block blockTr;
    static String blockMerkleRoot;

    public static void main(String[] args) throws Exception {
        BlockExplorer blockExplorer = new BlockExplorer();  // instantiate a block explorer

        String answer = "";  //the response to check whetehr to find previous block details or not
        int numberofTransactions = 0;  //variable to store number of transactions a block has
        System.out.println("Here is some information on the most recent block");
        
        LatestBlock latestBlock = blockExplorer.getLatestBlock();  //gets the lastest block in the blockchain, referred from Github
        long latestBlockHeight = latestBlock.getHeight();  //gets the height of a block in the block chain, referred from Github
        blockHash = latestBlock.getHash();  //gets the hash value of a block
        blockTr = blockExplorer.getBlock(blockHash);  //get a block by hash on blockExplorer, referred from Github

        do {
            System.out.println("Block hash");
            System.out.println("The hash value of the block is: " + blockHash);
            
            System.out.println("Merkle root");
            blockMerkleRoot = blockTr.getMerkleRoot();  //gets the MerkleRoot stored in the header of the block, referred from Github 
            System.out.println("The Merkle root for the block is: " + blockMerkleRoot);
            
            System.out.println("Number of transactions");
            numberofTransactions = blockTr.getTransactions().size();  //gets the list of transaction a block has and then the size of the transation list, referred from Github
            System.out.println("the number of transactions for this block are: " + numberofTransactions);
            
            System.out.println("Would you like to see another prior block? Enter 'y' for yes and 'n' for no ");
            Scanner sc = new Scanner(System.in);
            answer = sc.next();  //gets the option from user whether he wants to see the previous block
            
            blockHash = blockTr.getPreviousBlockHash();  //gets the hash value of the previous block 
            blockTr = blockExplorer.getBlock(blockHash);  //updates the blockTr to the previous block 
        } while (answer.equals("y"));

    }

}
