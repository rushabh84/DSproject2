/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rush
 */
public class ReadSensor {
    public static void main(String args[]){
        //creating an XML with the method/action name to be performed by the server, and depending on the element in the actiontodo tag, action done by server
        String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                                "<maintag>"+
                                "<actiontodo>getRoomStatusMsg</actiontodo>"+
                                "</maintag>";
        System.out.println(singleMessageOperations(xmlStr));  //call the web service to change to get the most recent room status and print the message the server sends back
    }
    //calling the web service singleMessageOperations remotely
    private static String singleMessageOperations(java.lang.String messageXML) {
        edu.cmu.andrew.rushabhs.SingleMessageAPI_Service service = new edu.cmu.andrew.rushabhs.SingleMessageAPI_Service();
        edu.cmu.andrew.rushabhs.SingleMessageAPI port = service.getSingleMessageAPIPort();
        return port.singleMessageOperations(messageXML);
    }
}
