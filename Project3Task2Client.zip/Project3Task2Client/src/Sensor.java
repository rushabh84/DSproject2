
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rush
 */
public class Sensor {
 double currentDBA = 0.0;
    Random rand;
    int id;

    Sensor(int id) {
        this.id = id;
        rand = new Random();
    }

    public double get() {

// Change the current noise level some random amount
        double newNoise = rand.nextInt(70);
        currentDBA = newNoise;
        return currentDBA;
    }   
}
