/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cmu.andrew.rush;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter; 
import java.io.StringReader;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

/**
 *
 * @author Rush
 */
@WebServlet(name = "APIDesignRestStyle", urlPatterns = {"/APIDesignRestStyle"})
public class APIDesignRestStyle extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    static BigInteger e1 = new BigInteger("65537");
    static BigInteger n1 = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
    static String currentSensorID;
    static String currentroomStatus;
    static String currenttimeStamp;
    String currentStatus = "";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("Console: doPost visited");

        BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
        String data = br.readLine();
        String messagetoSend;
        String reportRoomStatus;
        if (data.equals("")) {  //a condition to check if the xmlMessage sent by the client is empty or not
            response.setStatus(401);
            return;
        } else {
            //using Java's parser for parsing the XML
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder;
            Document sensorMessage = null;
            try {
                builder = factory.newDocumentBuilder();  //creating new instance of DocumentBuilder
                StringReader r = new StringReader(data);
                InputSource is = new InputSource(r);
                sensorMessage = builder.parse(is);  //Parsing the content of the given file as an XML document and returning a new DOM Document object

                int status = verifySignature(sensorMessage);  //call a method to verify signature and change the roomstatus
                if (status == 200) {  //return status 200 if status updated successfully
                    response.setStatus(200);
                    return;
                } else {
                    response.setStatus(409);
                    return;
                }

            } catch (Exception ex) {
                Logger.getLogger(APIDesignRestStyle.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    protected int verifySignature(Document sensorMessage) {
        int statuscode = 0;
        sensorMessage.getDocumentElement().normalize();

        Node n = sensorMessage.getElementsByTagName("maintag").item(0);  //Returns a Node from NodeList of all the Elements in document order with a given tag name

        Element eElement = (Element) n;  //converting the Node into an element to access the value stored by the tags of the node
        String sensorID = eElement.getElementsByTagName("sensorID").item(0).getTextContent();  //extracting the text value stored by the sensorID tag in the element
        String timeStamp = eElement.getElementsByTagName("timeStamp").item(0).getTextContent();  //extracting the text value stored by the timeStamp tag in the element
        String roomStatusMsg = eElement.getElementsByTagName("roomStatusMsg").item(0).getTextContent();  //extracting the text value stored by the roomStatusMsg tag in the element
        String signature = eElement.getElementsByTagName("signature").item(0).getTextContent();  //extracting the text value stored by the signature tag in the element

        String combination = sensorID + timeStamp + roomStatusMsg;  //concatenating sensor id, timestamp and roomstatus to use it to create signature
        System.out.println("Server end : " + combination);

        MessageDigest messageDigest;
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");

            messageDigest.update(combination.getBytes());  //Updates the digest using the ByteBuffer of encrypt
            byte[] messageDigestMD5 = messageDigest.digest();  //returns a byte array representation of the messagedigest 

            int len = messageDigestMD5.length;
            byte[] longByte = new byte[len + 1];
            longByte[0] = 0;  //setting the 1st byte as 0, i.e. the most significant byte since RSA works on positive number
            for (int i = 1; i <= len; i++) {
                longByte[i] = messageDigestMD5[i - 1];  //copying the bytes from messageDigest to the bytes from the 1st index of longByte byte array
            }

            BigInteger finalsign = new BigInteger(longByte);

            BigInteger todecrypt = new BigInteger(signature);  //converting the signature to BigInteger
            BigInteger decrypt = todecrypt.modPow(e1, n1);  //decrypting the hashed value of string combined

            if (finalsign.compareTo(decrypt) == 0) {//if the signature sent by the client and the one generated by the server matches, signature is authenticaed
                //and so change the room status, sesnor id and the timestamp and also update the message to be sent to the client
                currentSensorID = sensorID;
                currentroomStatus = roomStatusMsg;
                currenttimeStamp = timeStamp;
                statuscode = 200;  //set status code as 200 if roomstatus changed successfully

            } else {
                statuscode = 409;
            }
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(APIDesignRestStyle.class.getName()).log(Level.SEVERE, null, ex);
        }
        return statuscode;

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("Console: doGET visited");
        String result;
        // When doGet method is called the client requests to read the most recent roomstatus,the HTTP response code set to 200 OK
        response.setStatus(200);
        // tell the client the type of the response
        response.setContentType("text/plain;charset=UTF-8");

        // setting the message to return to the client, and writing the message back to client 
        result = "The last report at time " + currenttimeStamp + " shows the room to be " + currentroomStatus+".";
        PrintWriter out = response.getWriter();
        out.println(result);  //writing the message back to client
    }

}
