
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Rush
 */
class Result {

    String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}

public class ReadSensorData {

    public static void main(String arg[]) {
        System.out.println(readStatus());  //calling the doGet method to tell the server that it wants to read the most recent room status 
    }

   //Result class is created to store the message sent by the client and print the message on the client end
    public static String readStatus() {
        Result r = new Result();
        int status = 0;
        if ((status = doGet(r)) != 200) {
            return "Error from server " + status;
        }
        return r.getValue();
    }

    public static int doGet(Result r) {
        r.setValue(""); 
        String response = "";
        HttpURLConnection conn;
        int status = 0;

        try {
            // setting the URL appropriately to reach the servlet on the server
            URL url = new URL("http://localhost:8090/Project3Task3Server/APIDesignRestStyle");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            //tell the server what format we want back
            conn.setRequestProperty("Accept", "text/plain");
            //wait for response
            status = conn.getResponseCode();
            // If things went poorly, don't try to read any response, just return.
            if (status != 200) {
                //if the status wanst read properly from the server, return the responseCode of the connection established and set message as the response message of the connection
                String msg = conn.getResponseMessage();
                return conn.getResponseCode();
            }
            String output = "";
            // things went well so let's read the response sent by the server
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));
            while ((output = br.readLine()) != null) {
                response += output;
            }
            conn.disconnect();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //set the response object
        r.setValue(response);
        //return HTTP status to caller
        return status;

    }

}
