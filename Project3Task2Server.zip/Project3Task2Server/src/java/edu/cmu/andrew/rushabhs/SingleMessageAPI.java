/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cmu.andrew.rushabhs;

import java.io.StringReader;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

/**
 *
 * @author Rush
 */
@WebService(serviceName = "SingleMessageAPI")
public class SingleMessageAPI {

    static BigInteger e1 = new BigInteger("65537");
    static BigInteger n1 = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
    static String currentSensorID;
    static String currentroomStatus;
    static String currenttimeStamp;
    //String reportRoomStatus;
    String currentStatus = "";

    /**
     * Web service operation
     */
    /**
     * Web service operation
     *
     * @param messageXML
     * @return
     */
    @WebMethod(operationName = "singleMessageOperations")
    public String singleMessageOperations(@WebParam(name = "messageXML") String messageXML) {
        //TODO write your implementation code here:

        String messagetoSend;
        String reportRoomStatus;
        //using Java's parser for parsing the XML
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        Document sensorMessage = null;
        try {
            builder = factory.newDocumentBuilder();  //creating new instance of DocumentBuilder
            StringReader r = new StringReader(messageXML);
            InputSource is = new InputSource(r);
            sensorMessage = builder.parse(is);  //Parsing the content of the given file as an XML document and returning a new DOM Document object
            sensorMessage.getDocumentElement().normalize();

            Node n = sensorMessage.getElementsByTagName("maintag").item(0);  //Returns a Node from NodeList of all the Elements in document order with a given tag name

            Element eElement = (Element) n;  //converting the Node into an element to access the value stored by the tags of the node
            String action = eElement.getElementsByTagName("actiontodo").item(0).getTextContent();  //extracting the text value stored by the actionto tag in the element

            if (action.equals("roomChangeInStatus")) {  //a condition to check which client class called the web service and accpordingly perform action

                String sensorID = eElement.getElementsByTagName("sensorID").item(0).getTextContent();  //extracting the text value stored by the sensorID tag in the element
                String timeStamp = eElement.getElementsByTagName("timeStamp").item(0).getTextContent();  //extracting the text value stored by the timeStamp tag in the element
                String roomStatusMsg = eElement.getElementsByTagName("roomStatusMsg").item(0).getTextContent();  //extracting the text value stored by the roomStatusMsg tag in the element
                String signature = eElement.getElementsByTagName("signature").item(0).getTextContent();  //extracting the text value stored by the signature tag in the element

                String combination = sensorID + timeStamp + roomStatusMsg;  //concatenating sensor id, timestamp and roomstatus to use it to create signature
                System.out.println("Server end : " + combination);

                MessageDigest messageDigest;
                messageDigest = MessageDigest.getInstance("SHA-256");
                messageDigest.update(combination.getBytes());  //Updates the digest using the ByteBuffer of encrypt
                byte[] messageDigestMD5 = messageDigest.digest();  //returns a byte array representation of the messagedigest 

                int len = messageDigestMD5.length;
                byte[] longByte = new byte[len + 1];
                longByte[0] = 0;  //setting the 1st byte as 0, i.e. the most significant byte since RSA works on positive number
                for (int i = 1; i <= len; i++) {
                    longByte[i] = messageDigestMD5[i - 1];  //copying the bytes from messageDigest to the bytes from the 1st index of longByte byte array
                }

                BigInteger finalsign = new BigInteger(longByte);
    
                BigInteger todecrypt = new BigInteger(signature);  //converting the signature to BigInteger
                BigInteger decrypt = todecrypt.modPow(e1, n1);  //decrypting the hashed value of string combined

                if (finalsign.compareTo(decrypt) == 0) {//if the signature sent by the client and the one generated by the server matches, signature is authenticaed
                    //and so change the room status, sesnor id and the timestamp and also update the message to be sent to the client
                    currentSensorID = sensorID;
                    currentroomStatus = roomStatusMsg;
                    currenttimeStamp = timeStamp;
                    messagetoSend = "Ok successfully roomstatus changed";
                } else {
                    messagetoSend = "Invalid signature. Data isn't reported by an authenticated sensor device";
                }

                return messagetoSend;  //returns the message to the client

            }
            if (action.equals("getRoomStatusMsg")) {  //if the ReadSensor class called the webservice, returns the most recent room status
                reportRoomStatus = "The last report at time " + currenttimeStamp + " shows the room to be " + currentroomStatus;
                return reportRoomStatus;
            }

        } catch (Exception ex) {
            Logger.getLogger(SingleMessageAPI.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "no action taken";
    }
}
