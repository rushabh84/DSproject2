
import java.util.Random;

public class Sensor {

    double currentDBA = 0.0;
    Random rand;
    int id;

    Sensor(int id) {
        this.id = id;
        rand = new Random();
    }

    public double get() {

// Change the current noise level some random amount
        double newNoise = rand.nextInt(70);
        currentDBA = newNoise;
        return currentDBA;
    }
}
