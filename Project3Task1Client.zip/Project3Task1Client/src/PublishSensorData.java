
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Rush
 */
public class PublishSensorData {

    static BigInteger d1 = new BigInteger("339177647280468990599683753475404338964037287357290649639740920420195763493261892674937712727426153831055473238029100340967145378283022484846784794546119352371446685199413453480215164979267671668216248690393620864946715883011485526549108913");
    static BigInteger n1 = new BigInteger("2688520255179015026237478731436571621031218154515572968727588377065598663770912513333018006654248650656250913110874836607777966867106290192618336660849980956399732967369976281500270286450313199586861977623503348237855579434471251977653662553");
    static String previousStatus = "begin";

    public static void main(String args[]) {

        Sensor s = new Sensor(1);  //read sensor data
        while (true) {
            double sens = s.get();
            String currentStatus = checkcurrentStatus(sens);  //chechkcurrentStatus is a method to get the current roomstatus for the dBA value returned by Sensor class

            //next 4 lines of code is to read the timestamp using java.util.Date in the required format 
            DateFormat df = new SimpleDateFormat("E MMM dd HH:mm:ss");
            DateFormat df2 = new SimpleDateFormat("yyyy");
            Date dateobj = new Date();
            String timeStamp = (df.format(dateobj) + " EST " + df2.format(dateobj));
            //String timeStamp = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new java.util.Date());  //generating timestamp

            if (previousStatus.equals(currentStatus)) {
                //this condition is to check if the new value read is in the same range as the previously read message, so the check is based on the 
                //previous status and the current status
                System.out.println("Read " + (int)sens + " from sensor. No notification is being sent to the server.");  //if the status isn's same, print no notification sent
            } else {
                String signature = generateSignature(s.id, timeStamp, currentStatus);  //calls a method to generate a signature to sign the sensor message
                //prints appropriate message if the new value isn't in the same range as the previous value and then call the web service to change to roomStatus
                //and print the message the server sends back
                System.out.println("Read " + (int)sens + " from sensor. Notifying server that the room is " + currentStatus+".");
                System.out.println(roomChangeInStatus(String.valueOf(s.id), timeStamp, currentStatus, signature));

            }
            previousStatus = currentStatus;  //chaniging the roomstatus after every 5 seconds to compare the next new value to this value
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(PublishSensorData.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static String checkcurrentStatus(double sensordBA) {
        String currentroomStatus;
        //condition to check what will the status of the room be depedning on the range of the values given
        if (sensordBA < 30) {
            currentroomStatus = "unoccupied";
        } else if (sensordBA < 50 && sensordBA >= 30) {
            currentroomStatus = "occupied";
        } else {
            currentroomStatus = "busy";
        }
        return currentroomStatus;  //once the status is decided based on the range of values, return the value
    }

    public static String generateSignature(int id, String timeStamp, String roomStatus) {
        String combined = String.valueOf(id) + timeStamp + roomStatus;  //concatenating sensor id, timestamp and roomstatus to use it to create signature
        //using SH-256 algorithm to create hash of the combined string
        MessageDigest messageDigest;
        String sign = "";
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");

            messageDigest.update(combined.getBytes());  //Updates the digest using the ByteBuffer of encrypt
            byte[] messageDigestMD5 = messageDigest.digest();  //returns a byte array representation of the messagedigest 

            int len = messageDigestMD5.length;
            byte[] longByte = new byte[len + 1];  //creating a byet array of length that is 1 greater than messageDigest
            longByte[0] = 0;  //setting the 1st byte as 0, i.e. the most significant byte since RSA works on positive number
            for (int i = 1; i <= len; i++) {
                longByte[i] = messageDigestMD5[i - 1];  //copying the bytes from messageDigest to the bytes from the 1st index of longByte byte array
            }

            BigInteger toencrypt = new BigInteger(longByte);
            BigInteger encsym = toencrypt.modPow(d1, n1);  //encrypting the hashed value of string combined
            sign = encsym.toString();

        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(PublishSensorData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sign;
    }

    //calling the web service roomChangeStatus remotely
    private static String roomChangeInStatus(java.lang.String sensorID, java.lang.String timeStamp, java.lang.String roomStatusMsg, java.lang.String signature) {
        edu.cmu.andrew.rushabhs.Project3RPI_Service service = new edu.cmu.andrew.rushabhs.Project3RPI_Service();
        edu.cmu.andrew.rushabhs.Project3RPI port = service.getProject3RPIPort();
        return port.roomChangeInStatus(sensorID, timeStamp, roomStatusMsg, signature);
    }

}
