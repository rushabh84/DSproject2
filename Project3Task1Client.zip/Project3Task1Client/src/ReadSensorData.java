/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rush
 */
public class ReadSensorData {
    public static void main(String args[]) {
        System.out.println(getRoomStatusMsg());  //call the web service to change to get the most recent room status and print the message the server sends back
    }

    //calling the web service getRoomStatusMsg remotely
    private static String getRoomStatusMsg() {
        edu.cmu.andrew.rushabhs.Project3RPI_Service service = new edu.cmu.andrew.rushabhs.Project3RPI_Service();
        edu.cmu.andrew.rushabhs.Project3RPI port = service.getProject3RPIPort();
        return port.getRoomStatusMsg();
    }
    
}
